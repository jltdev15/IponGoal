import React, { useState } from 'react';
import { Text } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { MainStackParams } from '../navigation/types';
import { useAuthStore } from '../stores/authStore';
import { updateProfile } from '../database/repositories/userRepository';
import { ScreenContainer } from '../components/ScreenContainer';
import { AppInput } from '../components/AppInput';
import { AppButton } from '../components/AppButton';
import { theme } from '../theme/theme';
import { useFormAction } from '../services/useFormAction';
export function EditProfileScreen({
  navigation,
}: NativeStackScreenProps<MainStackParams, 'EditProfile'>) {
  const user = useAuthStore(s => s.user)!,
    refreshUser = useAuthStore(s => s.refreshUser),
    [name, setName] = useState(user.fullName),
    [grade, setGrade] = useState(user.gradeLevel),
    { busy, error, run } = useFormAction();
  return (
    <ScreenContainer>
      <Text style={theme.title}>Your local profile</Text>
      <AppInput
        label="Full Name"
        value={name}
        onChangeText={setName}
        maxLength={80}
      />
      <AppInput
        label="Grade Level (optional)"
        value={grade}
        onChangeText={setGrade}
        maxLength={40}
      />
      <Text style={theme.muted}>Username: @{user.username}</Text>
      {!!error && (
        <Text accessibilityRole="alert" style={theme.error}>
          {error}
        </Text>
      )}
      <AppButton
        title="Save Profile"
        loading={busy}
        onPress={() => {
          void run(() => {
            updateProfile(user.id, name, grade);
            refreshUser();
            navigation.goBack();
          }, 'Unable to update your profile.');
        }}
      />
    </ScreenContainer>
  );
}
