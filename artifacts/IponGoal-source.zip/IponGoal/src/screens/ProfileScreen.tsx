import React from 'react';
import { Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { MainStackParams } from '../navigation/types';
import { useAuthStore } from '../stores/authStore';
import { useGoalStore } from '../stores/goalStore';
import { useSavingsStore } from '../stores/savingsStore';
import { ScreenContainer } from '../components/ScreenContainer';
import { AppButton } from '../components/AppButton';
import { confirmAction } from '../components/ConfirmationModal';
import { theme } from '../theme/theme';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';
import { appConfig } from '../config/appConfig';
import { useFormAction } from '../services/useFormAction';
export function ProfileScreen() {
  const navigation =
      useNavigation<NativeStackNavigationProp<MainStackParams>>(),
    user = useAuthStore(s => s.user)!,
    logout = useAuthStore(s => s.logout),
    reset = useAuthStore(s => s.reset);
  const goals = useGoalStore(s => s.goals),
    entries = useSavingsStore(s => s.savings),
    { busy, error, run } = useFormAction();
  return (
    <ScreenContainer>
      <View style={{ alignItems: 'center', gap: 10 }}>
        <View
          style={{
            width: 80,
            height: 80,
            borderRadius: 28,
            backgroundColor: colors.primarySoft,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text style={[theme.title, { color: colors.primary }]}>
            {user.fullName
              .trim()
              .split(/\s+/)
              .slice(0, 2)
              .map(n => n[0])
              .join('')
              .toUpperCase()}
          </Text>
        </View>
        <Text style={theme.title}>{user.fullName}</Text>
        {!!user.gradeLevel && <Text style={theme.body}>{user.gradeLevel}</Text>}
        <Text style={theme.muted}>@{user.username} · Offline profile</Text>
      </View>
      <View style={theme.card}>
        <Text style={theme.heading}>Savings Summary</Text>
        <Text style={theme.amount}>
          {formatCurrency(
            entries.reduce((n, s) => n + s.amount, 0),
            true,
          )}
        </Text>
        <Text style={theme.muted}>
          {goals.filter(g => g.status === 'active').length} active ·{' '}
          {goals.filter(g => g.status === 'completed').length} completed
        </Text>
      </View>
      <View style={{ gap: 10 }}>
        <AppButton
          title="Edit Profile"
          variant="secondary"
          onPress={() => navigation.navigate('EditProfile')}
        />
        <AppButton
          title="Completed Goals"
          variant="secondary"
          onPress={() => navigation.navigate('CompletedGoals')}
        />
        <AppButton
          title="Archived Goals"
          variant="secondary"
          onPress={() => navigation.navigate('ArchivedGoals')}
        />
        <Text style={[theme.body, { padding: 16 }]}>
          Currency: Philippine Peso ({appConfig.DEFAULT_CURRENCY})
        </Text>
        <AppButton
          title="About the App"
          variant="secondary"
          onPress={() => navigation.navigate('About')}
        />
        <AppButton
          title="Logout"
          variant="secondary"
          disabled={busy}
          onPress={() => {
            void run(logout, 'Unable to log out. Please try again.');
          }}
        />
      </View>
      <Text style={theme.muted}>
        Accounts and savings are stored only on this device. Uninstalling the
        app removes them.
      </Text>
      <AppButton
        title="Reset App Data"
        variant="secondary"
        disabled={busy}
        onPress={() =>
          confirmAction(
            'Reset all app data?',
            'This will permanently remove ALL profiles, goals, and savings history from this device. This cannot be undone.',
            'Continue',
            () =>
              confirmAction(
                'Permanently reset this device?',
                'All local accounts and their records will be erased.',
                'Reset Data',
                () => {
                  void run(
                    reset,
                    'Unable to reset your data. Please try again.',
                  );
                },
              ),
          )
        }
      />
      {!!error && (
        <Text accessibilityRole="alert" style={theme.error}>
          {error}
        </Text>
      )}
    </ScreenContainer>
  );
}
