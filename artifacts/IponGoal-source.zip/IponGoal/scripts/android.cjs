const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const javaName = process.platform === 'win32' ? 'java.exe' : 'java';

function isJdk17(home) {
  if (
    !home ||
    !fs.existsSync(
      path.join(
        home,
        'bin',
        'javac' + (process.platform === 'win32' ? '.exe' : ''),
      ),
    )
  ) {
    return false;
  }
  const result = spawnSync(path.join(home, 'bin', javaName), ['-version'], {
    encoding: 'utf8',
    timeout: 10000,
  });
  return (
    result.status === 0 &&
    /version "17(?:\.|"|\-)/.test(result.stderr + result.stdout)
  );
}

function findJdk17() {
  const candidates = [process.env.JAVA_HOME];
  if (process.platform === 'darwin') {
    const result = spawnSync('/usr/libexec/java_home', ['-v', '17'], {
      encoding: 'utf8',
      timeout: 10000,
    });
    if (result.status === 0) {
      candidates.push(result.stdout.trim());
    }
  }
  const directories =
    process.platform === 'win32'
      ? ['Java', 'Eclipse Adoptium', 'Microsoft', 'Amazon Corretto'].map(name =>
          path.join(process.env.ProgramFiles || 'C:\\Program Files', name),
        )
      : process.platform === 'darwin'
      ? [
          '/Library/Java/JavaVirtualMachines',
          '/opt/homebrew/opt/openjdk@17',
          '/usr/local/opt/openjdk@17',
        ]
      : ['/usr/lib/jvm', '/usr/java'];
  for (const directory of directories) {
    if (!fs.existsSync(directory)) {
      continue;
    }
    candidates.push(directory);
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      if (entry.isDirectory() || entry.isSymbolicLink()) {
        candidates.push(path.join(directory, entry.name));
        candidates.push(path.join(directory, entry.name, 'Contents', 'Home'));
      }
    }
  }
  return [...new Set(candidates)].find(isJdk17);
}

const javaHome = findJdk17();
if (!javaHome) {
  console.error(
    'JDK 17 is required to build Ipon Goal. Install JDK 17 and set JAVA_HOME to its directory, then rerun npm run android.',
  );
  process.exitCode = 1;
} else {
  console.log(`Using JDK 17: ${javaHome}`);
  const flags = process.argv.slice(2);
  if (!flags.includes('--jdk-check')) {
    const child = spawn(
      process.execPath,
      [require.resolve('react-native/cli.js'), 'run-android', ...flags],
      {
        cwd: root,
        stdio: 'inherit',
        env: {
          ...process.env,
          JAVA_HOME: javaHome,
          PATH: `${path.join(javaHome, 'bin')}${path.delimiter}${
            process.env.PATH || ''
          }`,
        },
      },
    );
    child.once('error', error => {
      console.error(error.message);
      process.exitCode = 1;
    });
    child.once('exit', code => {
      process.exitCode = code ?? 1;
    });
    process.on('SIGINT', () => child.kill('SIGINT'));
    process.on('SIGTERM', () => child.kill('SIGTERM'));
  }
}
