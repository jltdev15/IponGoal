# QA record

## Automated verification

- Strict TypeScript: passed.
- ESLint: passed, no errors or warnings.
- Jest: 30 tests passed in two suites. Production SQL is exercised against actual SQLite using Node 24; native JSI compatibility is checked separately through the Android build/emulator.
- Native debug build: passed; final branded ARM debug/release builds passed; results are recorded in `build-final.log`.

Covered: valid registration, duplicate/case-insensitive username, mismatched/short passwords, valid/invalid login, session flags and logout, goal CRUD, empty/cascading deletion, archive/restore, savings CRUD, over-target balances, completion and demotion after update/delete/target edits, inclusive history filtering, deterministic statistics, profile changes, reset, empty database, decimal/large/invalid amounts, multiple goals/accounts and ownership protections, missing records, date/leap/week helpers, schema migration constraints, immediate duplicate-submit protection, and redaction of database errors.

## Native emulator checks

Tests use an isolated emulator account on Android API 35 (API 37 was also used for the initial startup/layout check), with Wi-Fi and mobile data disabled and airplane-mode setting enabled. No production seed account is created by the app. Screenshots are in `screenshots/`. Native smoke results are updated below as performed.

| Check | Result |
| --- | --- |
| Bundled debug APK opens without Metro or connectivity | Passed |
| Release APK manifest has no INTERNET permission | Passed (aapt) |
| Welcome at 360×800 dp | Passed |
| Scrollable registration form at 360×800 dp | Passed |
| Native offline registration and login | Passed (API 35) |
| Create a goal, save ₱100.25, complete goal | Passed |
| History and statistics show matching ₱100.25 totals | Passed |
| Delete savings entry reopens completed goal | Passed |
| Save ₱25.50: 25% displayed, ₱74.75 remaining | Passed |
| Archive/restore preserves ₱25.50 history and balance | Passed |
| Remember Me, force-stop/reopen, APK reinstall persistence | Passed |
| Active Home at 360×800, 390×844, 412×915 dp | Passed |
| Logout opens Login directly; login retains savings | Passed |
| Two-step reset removes data and returns to Welcome | Passed |
| Final API 35 ReactNativeJS/AndroidRuntime error log | Empty |

## Reproducible full manual checklist

1. Fresh install: Welcome → Get Started → Register. Reject blank name, short username/password, mismatched passwords. Valid registration opens empty Home.
2. Logout; reject wrong credentials. Login correctly; verify goals persist. Repeat registration with duplicate username and reject it.
3. Login without Remember Me, force-stop/reopen: Login. Login with Remember Me, force-stop/reopen: Home. Logout clears remember preference, preserves records.
4. Create Phone target ₱15,000 and starting ₱4,500. Verify 30%, ₱10,500 remaining, one starting transaction. Edit name/date/category/target. Create zero/negative/invalid targets and reject them.
5. Create with starting amount equal to or over target: immediately completed, real amount preserved. No zero transaction inserted for starting 0.
6. Add ₱100.25; verify 4,600.25 balance. Double-tap Save rapidly: exactly one entry. Check keyboard and form scroll.
7. Reach/exceed target; choose Keep Saving, then Mark as Completed from details. Check completed collection and completion date.
8. Edit/delete a completed goal's savings so total is below target: becomes active and completion date clears. Raise target above balance: also reopens.
9. History: All, By Goal, This Week, This Month, custom date range. Check inclusivity, filtered totals, sorting/grouping, missing/invalid ranges and empty view.
10. Statistics: compare total/week/month/average/count/goals against records, month buckets including a fifth week, and future-dated entry exclusion from current periods.
11. Archive; verify history and totals remain, active/completed counts exclude it. Restore; status reflects balance. Try adding to archive: require restoration.
12. Delete empty goal; delete goal with transactions after warning; cancelling preserves records. Delete entry confirmation adjusts totals.
13. Edit profile; username stays stable. Completed/archived/About/PHP labels work. Back navigation does not expose another account.
14. Register a second account, confirm first account's financial records are invisible. Log back into first account and recover its records.
15. Two-step reset: cancel each step, then confirm. All device accounts, goals, savings, and session disappear; Welcome returns and registration still works.
16. Repeat core workflow with airplane mode, Wi-Fi off, data off, Metro stopped. Force-stop/reopen after saving to verify persistence.
17. Repeat primary screens at 360×800, 390×844, 412×915 dp. Check long names, decimal/large values, keyboard, Android Back, larger font size, and TalkBack.
18. Optional physical-device QA: low-end API 24+ phone, portrait/landscape, repeated open/close, background/foreground, interrupted form entry, and reinstall behavior.

Remaining physical-device/TalkBack checks should be performed before classroom research deployment. The generated iOS scaffold is not covered.

The API 37 emulator initially used software rendering and became unresponsive during native release compilation with host memory pressure; this appears to be an emulator/host resource issue. Final smoke testing was repeated with hardware rendering on API 35 after compilation. No app crashes occurred in the final API 35 smoke flow.

## Development launcher update

`npm start` now offers an emulator picker before Metro. Verified installed AVD discovery, running-device labels, invalid-number retry, Metro-only choice, forwarded `--port 8088`, normal Metro r/d/j keys, Ctrl+C cleanup, missing-name feedback, and ESLint/syntax checks. No runtime app or APK changes were needed.

`npm run android` now discovers JDK 17 and supplies it to the React Native CLI/Gradle subprocess. Verified discovery with `JAVA_HOME` explicitly pointing to the installed JDK 26, CLI flag forwarding, syntax, and ESLint. Ran `npm run android -- --no-packager --extra-params=-PreactNativeArchitectures=arm64-v8a`: Gradle completed successfully in 59 seconds, installed on Pixel_10_Pro_XL (API 37), and launched MainActivity. This resolves the reported Java 26 `JdkImageTransform` failure. Windows/Linux discovery is implemented but not verified on those operating systems.
